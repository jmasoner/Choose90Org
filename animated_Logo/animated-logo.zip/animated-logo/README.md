# Choose90 Animated Logo System

> A modular, reusable animated logo component for WordPress and static HTML sites

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![WordPress](https://img.shields.io/badge/WordPress-5.0%2B-blue.svg)
![PHP](https://img.shields.io/badge/PHP-7.4%2B-purple.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)

---

## 📋 Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Project Structure](#project-structure)
- [Installation](#installation)
  - [Method 1: WordPress Plugin](#method-1-wordpress-plugin-recommended)
  - [Method 2: Theme Integration](#method-2-theme-integration)
  - [Method 3: Static HTML](#method-3-static-html-pages)
- [Configuration](#configuration)
- [Customization Guide](#customization-guide)
- [File Descriptions](#file-descriptions)
- [Troubleshooting](#troubleshooting)
- [Performance](#performance)
- [Security](#security)
- [Changelog](#changelog)
- [Contributing](#contributing)
- [Support](#support)
- [License](#license)
- [Author](#author)

---

## 🎯 Overview

The **Choose90 Animated Logo System** is a lightweight, modular solution for displaying an animated SVG logo across multiple pages on a hybrid WordPress/static HTML website. It follows the **DRY (Don't Repeat Yourself)** principle, allowing you to maintain the logo in a single location while using it site-wide.

### The Problem This Solves

Traditional approaches require duplicating logo code across multiple HTML files, leading to:
- ❌ Maintenance nightmares (updating 6+ files for one change)
- ❌ Inconsistent animations across pages
- ❌ Bloated page sizes (CSS/SVG repeated on every page)
- ❌ Version control conflicts

### The Solution

This system provides:
- ✅ **Single source of truth** - Edit once, update everywhere
- ✅ **Modular architecture** - Works with WordPress, static HTML, or both
- ✅ **Performance optimized** - CSS cached by browser, SVG reused
- ✅ **Easy maintenance** - Change colors, timing, spacing in one file
- ✅ **Security hardened** - No external dependencies, safe code practices

---

## ✨ Features

### Animation Capabilities
- **Slide-in effects** from left and right for figure elements
- **Fade and scale** animations for connecting elements
- **Smooth text fade-in** with vertical translation
- **Hover effects** with scale transformation
- **Responsive design** with mobile breakpoints
- **Customizable timing** and easing functions

### Technical Features
- **Zero external dependencies** (except optional Google Fonts)
- **Lightweight** (~8KB total uncompressed)
- **Browser cached** CSS for optimal performance
- **Accessibility compliant** (ARIA labels, semantic HTML)
- **SEO friendly** (proper title tags, no layout shifts)
- **Version controlled** with semantic versioning

### Integration Options
- **WordPress Plugin** - Safest, easiest activation/deactivation
- **Theme Integration** - Direct integration with theme's functions.php
- **PHP Includes** - For static HTML pages with PHP support
- **JavaScript Fallback** - For non-PHP environments (optional)

---

## 📁 Project Structure

```
animated-logo/
│
├── README.md                           # This file - comprehensive documentation
├── LICENSE                             # MIT License
├── CHANGELOG.md                        # Version history and updates
├── .gitignore                          # Git ignore rules
│
├── src/                                # Source files
│   ├── css/
│   │   └── logo-animated.css           # Animation styles (single source of truth)
│   ├── php/
│   │   ├── logo-animated.php           # PHP component for static HTML
│   │   └── header-logo.php             # WordPress template part
│   ├── js/
│   │   └── logo-animated.js            # JavaScript fallback (optional)
│   └── wordpress-plugin/
│       └── choose90-logo-system.php    # Complete WordPress plugin
│
├── docs/                               # Additional documentation
│   ├── INSTALLATION.md                 # Detailed installation guide
│   ├── CUSTOMIZATION.md                # How to customize the logo
│   ├── TROUBLESHOOTING.md              # Common issues and solutions
│   └── DEPLOYMENT.md                   # Deployment strategies (cPanel, SSH, PowerShell)
│
├── examples/                           # Example implementations
│   ├── wordpress-header.php            # Example WordPress header.php
│   ├── static-page.php                 # Example static HTML page
│   └── theme-functions.php             # Example theme functions.php additions
│
├── tests/                              # Test files
│   └── demo.html                       # Standalone demo page
│
└── deployment/                         # Deployment scripts
    ├── deploy-cpanel.sh                # cPanel deployment script
    ├── deploy-ssh.sh                   # SSH deployment script
    └── deploy-powershell.ps1           # PowerShell deployment script
```

---

## 🚀 Installation

### Prerequisites

- **WordPress**: 5.0 or higher (for WordPress integration)
- **PHP**: 7.4 or higher (for PHP includes)
- **Server**: Apache or Nginx with PHP support
- **Browser**: Modern browser with CSS3 animation support

### Method 1: WordPress Plugin (Recommended)

**Best for**: Sites primarily using WordPress, users who want easy activation/deactivation

#### Step-by-Step:

1. **Download the plugin file:**
   - File: `src/wordpress-plugin/choose90-logo-system.php`

2. **Upload via cPanel File Manager:**
   ```
   Navigate to: /home/YOUR_USERNAME/YOUR_SITE/wp-content/plugins/
   Upload: choose90-logo-system.php
   ```

3. **Or upload via WordPress Admin:**
   - Go to **Plugins → Add New → Upload Plugin**
   - Choose `choose90-logo-system.php`
   - Click **Install Now**

4. **Activate the plugin:**
   - Go to **Plugins** menu
   - Find "Choose90 Logo System"
   - Click **Activate**

5. **Upload supporting files:**
   ```
   /css/logo-animated.css                                  ← Upload to site root /css/ folder
   /includes/logo-animated.php                             ← Upload to site root /includes/ folder
   /wp-content/themes/YOUR-THEME/template-parts/header-logo.php  ← Upload to theme
   ```

6. **Update your theme's header.php:**
   ```php
   <?php get_template_part('template-parts/header', 'logo'); ?>
   ```

7. **Whitelist in security plugins (if applicable):**
   - **BPS (BulletProof Security)**: Add `choose90-logo-system.php` to HPF Ignore Rules
   - **Wordfence**: Mark as safe in scan results
   - **Sucuri**: Add to whitelist

**✅ Done!** Your WordPress pages now use the animated logo.

---

### Method 2: Theme Integration

**Best for**: Users comfortable editing theme files, no plugin preference

#### Step-by-Step:

1. **Locate your theme's functions.php:**
   ```
   /wp-content/themes/YOUR-THEME/functions.php
   ```
   ⚠️ **IMPORTANT**: Use your THEME's functions.php, NOT `/wp-includes/functions.php`

2. **Add the enqueue code:**
   
   Open `functions.php` and add at the bottom:
   ```php
   /**
    * Enqueue Choose90 animated logo styles
    */
   function choose90_enqueue_logo_styles() {
       wp_enqueue_style(
           'choose90-logo-animated',
           get_stylesheet_directory_uri() . '/css/logo-animated.css',
           array(),
           '1.0.0',
           'all'
       );
   }
   add_action('wp_enqueue_scripts', 'choose90_enqueue_logo_styles');

   /**
    * Enqueue Outfit font (if not already loaded)
    */
   function choose90_enqueue_fonts() {
       wp_enqueue_style(
           'choose90-outfit-font',
           'https://fonts.googleapis.com/css2?family=Outfit:wght@700&display=swap',
           array(),
           null
       );
   }
   add_action('wp_enqueue_scripts', 'choose90_enqueue_fonts');
   ```

3. **Upload files:**
   ```
   /wp-content/themes/YOUR-THEME/css/logo-animated.css
   /wp-content/themes/YOUR-THEME/template-parts/header-logo.php
   ```

4. **Update header.php** (same as plugin method)

**✅ Done!** Logo system integrated directly into your theme.

---

### Method 3: Static HTML Pages

**Best for**: Non-WordPress pages, landing pages, standalone HTML files

#### Step-by-Step:

1. **Rename HTML files to PHP:**
   ```
   index.html  →  index.php
   about.html  →  about.php
   ```
   ℹ️ Your web server will serve `.php` files just like `.html`, but with PHP support enabled

2. **Add CSS to `<head>` section:**
   ```html
   <link rel="stylesheet" href="/css/logo-animated.css">
   ```

3. **Add logo where needed:**
   ```html
   <header>
       <?php include $_SERVER['DOCUMENT_ROOT'] . '/includes/logo-animated.php'; ?>
       <nav>
           <!-- Your navigation -->
       </nav>
   </header>
   ```

4. **Upload files:**
   ```
   /css/logo-animated.css
   /includes/logo-animated.php
   ```

**✅ Done!** Static pages now display the animated logo.

---

## ⚙️ Configuration

### Directory Structure Requirements

The system expects files at these locations:

```
YOUR_SITE_ROOT/
├── css/
│   └── logo-animated.css              # Required for ALL methods
├── includes/
│   └── logo-animated.php              # Required for static HTML only
└── wp-content/
    ├── plugins/
    │   └── choose90-logo-system.php   # Required for plugin method
    └── themes/
        └── YOUR-THEME/
            └── template-parts/
                └── header-logo.php    # Required for WordPress integration
```

### Web Server Configuration

**Apache (.htaccess):**
```apache
# Allow PHP processing of .php files
AddType application/x-httpd-php .php

# Optional: Rewrite .html to .php
RewriteEngine On
RewriteCond %{REQUEST_FILENAME}.php -f
RewriteRule ^(.*)\.html$ $1.php [L]
```

**Nginx:**
```nginx
# Process PHP files
location ~ \.php$ {
    include fastcgi_params;
    fastcgi_pass unix:/var/run/php/php7.4-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
}
```

### Font Loading

The system uses **Google Fonts (Outfit)**. Options:

1. **CDN (Default):**
   ```html
   <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@700&display=swap" rel="stylesheet">
   ```

2. **Self-hosted (Privacy-focused):**
   - Download Outfit font from Google Fonts
   - Place in `/fonts/` directory
   - Update CSS:
   ```css
   @font-face {
       font-family: 'Outfit';
       src: url('/fonts/Outfit-Bold.woff2') format('woff2');
       font-weight: 700;
   }
   ```

---

## 🎨 Customization Guide

### Change Animation Speed

**File**: `src/css/logo-animated.css`

**Line 15-27**: Modify duration values
```css
.logo-animated svg .figure-blue {
    animation: slideInLeft 0.8s ease-out;  /* Change 0.8s to 1.2s for slower */
}

.logo-animated svg .figure-yellow {
    animation: slideInRight 0.8s ease-out; /* Change 0.8s to 1.2s for slower */
}
```

**Effect**: Slower = more dramatic, Faster = more snappy

---

### Adjust Spacing Between "CHOOSE" and "90"

**Files**: 
- `src/php/logo-animated.php` (for static HTML)
- `src/php/header-logo.php` (for WordPress)

**Line 33**: Modify `x` coordinate
```html
<text class="logo-text" x="235" y="95" ...>90</text>
<!-- Increase x="235" to x="250" for more space -->
<!-- Decrease to x="220" for less space -->
```

**Visual guide**:
```
x="200"  →  CHOOSE90       (too close)
x="235"  →  CHOOSE 90      (default - balanced)
x="270"  →  CHOOSE    90   (more space)
```

---

### Change Logo Colors

**File**: `src/css/logo-animated.css`

**Inline styles in SVG** (lines 28-30):
```css
.logo-animated svg .figure-blue { 
    fill: #0066CC;   /* Blue figure - Change to any hex color */
}
.logo-animated svg .figure-yellow { 
    fill: #E8B93E;   /* Yellow figure - Change to any hex color */
}
.logo-animated svg .figure-gray { 
    fill: #9CA3AF;   /* Gray figure - Change to any hex color */
}
```

**Brand color examples**:
```css
/* Corporate blue/gold */
fill: #003366; (blue)
fill: #FFD700; (gold)

/* Modern tech */
fill: #6366F1; (indigo)
fill: #F59E0B; (amber)

/* Eco-friendly */
fill: #10B981; (green)
fill: #F97316; (orange)
```

---

### Modify Logo Size

**File**: `src/css/logo-animated.css`

**Line 13**: Change SVG width
```css
.logo-animated svg {
    width: 180px;      /* Default size */
    /* width: 140px;   Smaller for mobile-first */
    /* width: 220px;   Larger for desktop hero sections */
}
```

**Responsive sizing**:
```css
/* Desktop */
@media (min-width: 1024px) {
    .logo-animated svg {
        width: 220px;
    }
}

/* Tablet */
@media (max-width: 768px) {
    .logo-animated svg {
        width: 160px;
    }
}

/* Mobile */
@media (max-width: 480px) {
    .logo-animated svg {
        width: 120px;
    }
}
```

---

### Disable Hover Effect

**File**: `src/css/logo-animated.css`

**Line 9-11**: Comment out or remove
```css
/* .logo-animated:hover {
    transform: scale(1.05);
} */
```

---

### Change Animation Easing

**File**: `src/css/logo-animated.css`

**Lines 15-27**: Modify timing function
```css
animation: slideInLeft 0.8s ease-out;     /* Default - smooth deceleration */
animation: slideInLeft 0.8s ease-in;      /* Accelerates into position */
animation: slideInLeft 0.8s ease-in-out;  /* Smooth start and end */
animation: slideInLeft 0.8s linear;       /* Constant speed */
animation: slideInLeft 0.8s cubic-bezier(0.68, -0.55, 0.265, 1.55); /* Bounce */
```

**Easing visualizer**: https://cubic-bezier.com/

---

### Add Logo Click Tracking

**File**: `src/php/logo-animated.php` or `src/php/header-logo.php`

**Modify `<a>` tag**:
```html
<a href="/" 
   class="logo-animated" 
   aria-label="Choose90 Home"
   onclick="gtag('event', 'logo_click', {'event_category': 'navigation'});">
    <!-- SVG code -->
</a>
```

For Google Analytics 4, ensure `gtag.js` is loaded.

---

## 📄 File Descriptions

### Core Files

#### `src/css/logo-animated.css` (2.0KB)
**Purpose**: Contains all animation keyframes, timing, and styling
**Used by**: ALL pages (WordPress and static HTML)
**Dependencies**: None
**Loaded via**: 
- WordPress: Plugin or theme's `wp_enqueue_style()`
- Static HTML: `<link rel="stylesheet" href="/css/logo-animated.css">`

**Key sections**:
- Lines 1-11: Base logo container styles
- Lines 13-27: Animation assignments
- Lines 29-95: Keyframe definitions
- Lines 97-109: Responsive breakpoints

---

#### `src/php/logo-animated.php` (1.8KB)
**Purpose**: PHP component containing the SVG markup for static HTML pages
**Used by**: Static HTML pages (index.php, about.php, etc.)
**Dependencies**: `logo-animated.css`
**Loaded via**: `<?php include $_SERVER['DOCUMENT_ROOT'] . '/includes/logo-animated.php'; ?>`

**Structure**:
- Lines 1-8: PHP header comments and documentation
- Lines 10-39: Complete SVG logo markup
- Line 11: Link to homepage (`href="/"`)
- Lines 14-16: Blue figure (slides from left)
- Lines 18-20: Yellow figure (slides from right)
- Lines 22-24: Gray figure (fades and scales)
- Lines 26-30: Connecting arcs forming "90" shape
- Lines 32-34: Text elements "CHOOSE" and "90"

---

#### `src/php/header-logo.php` (1.9KB)
**Purpose**: WordPress template part for the animated logo
**Used by**: WordPress pages via `get_template_part()`
**Dependencies**: `logo-animated.css`
**Loaded via**: `<?php get_template_part('template-parts/header', 'logo'); ?>`

**Differences from `logo-animated.php`**:
- Uses `home_url()` instead of hardcoded `/`
- Uses `bloginfo()` for dynamic site name in title
- Designed for WordPress theme integration

---

#### `src/js/logo-animated.js` (2.7KB) - Optional
**Purpose**: JavaScript fallback for non-PHP environments
**Used by**: Edge cases where PHP includes aren't available
**Dependencies**: `logo-animated.css`
**Loaded via**: `<script src="/js/logo-animated.js"></script>`

**Usage**:
```html
<div id="animated-logo-container"></div>
<script src="/js/logo-animated.js"></script>
```

**When to use**:
- Static HTML sites without PHP support
- Client-side rendered applications
- Testing environments

---

### WordPress Integration

#### `src/wordpress-plugin/choose90-logo-system.php` (2.0KB)
**Purpose**: Complete WordPress plugin for easy activation/deactivation
**Used by**: WordPress sites preferring plugin-based integration
**Dependencies**: None (self-contained)
**Loaded via**: WordPress Plugin Manager

**Features**:
- Enqueues `logo-animated.css` automatically
- Loads Outfit font from Google Fonts
- Shows activation notice with file checklist
- Uses WordPress transients for one-time notices
- Prevents direct file access (`ABSPATH` check)

**Hooks used**:
- `wp_enqueue_scripts` - Loads CSS and fonts
- `register_activation_hook` - Sets activation transient
- `admin_notices` - Displays setup instructions

**Security measures**:
- Direct access prevention
- Uses WordPress functions exclusively
- No database writes
- No file modifications
- Escapes all output

---

### Documentation Files

#### `docs/INSTALLATION.md`
Detailed installation instructions for all three methods, including:
- Server requirements
- Step-by-step guides with screenshots
- Troubleshooting common installation issues
- Verification steps

#### `docs/CUSTOMIZATION.md`
Comprehensive customization guide covering:
- Visual customization (colors, sizes, spacing)
- Animation timing and easing
- Advanced modifications
- Brand adaptation examples

#### `docs/TROUBLESHOOTING.md`
Common issues and solutions:
- Logo not appearing
- Animation not playing
- CSS conflicts
- PHP include errors
- WordPress plugin conflicts

#### `docs/DEPLOYMENT.md`
Deployment strategies and automation:
- cPanel deployment guide
- SSH deployment with rsync
- PowerShell automation scripts
- CI/CD integration examples
- Rollback procedures

---

### Example Files

#### `examples/wordpress-header.php`
Complete example of a WordPress `header.php` file showing:
- Proper DOCTYPE and meta tags
- CSS/font loading
- Logo placement in header
- Navigation integration

#### `examples/static-page.php`
Complete example of a static HTML page showing:
- PHP include usage
- CSS loading
- Responsive structure
- Semantic HTML

#### `examples/theme-functions.php`
Example code to add to WordPress theme's `functions.php`:
- CSS enqueueing
- Font loading
- Optional custom functions

---

### Deployment Scripts

#### `deployment/deploy-cpanel.sh`
Bash script for cPanel deployments:
- Uploads files via FTP
- Sets correct permissions
- Creates necessary directories
- Validates file placement

#### `deployment/deploy-ssh.sh`
Bash script for SSH deployments:
- Uses rsync for efficient transfers
- Preserves file permissions
- Creates backups before deployment
- Validates server connectivity

#### `deployment/deploy-powershell.ps1`
PowerShell script for Windows users:
- Connects to WebDisk (Z: drive)
- Copies files to correct locations
- Validates paths
- Provides deployment summary

---

## 🐛 Troubleshooting

### Logo Doesn't Appear

**Symptoms**: Blank space where logo should be, broken image icon, or no logo at all

**Diagnosis**:
```bash
# Check if CSS file exists
curl -I https://your-site.com/css/logo-animated.css

# Should return: HTTP/1.1 200 OK
# If 404: File not uploaded or wrong path
```

**Solutions**:

1. **Verify file uploads**:
   - cPanel File Manager → Check `/css/logo-animated.css` exists
   - Check `/includes/logo-animated.php` exists (for static HTML)
   - Check template part exists (for WordPress)

2. **Check file permissions**:
   ```bash
   # Files should be 644
   chmod 644 /path/to/logo-animated.css
   chmod 644 /path/to/logo-animated.php
   ```

3. **Verify PHP include path**:
   ```php
   <?php 
   // Add debug output
   echo $_SERVER['DOCUMENT_ROOT']; 
   // Should show: /home/username/your-site.com
   ?>
   ```

4. **Check for PHP errors**:
   - Enable error display temporarily:
   ```php
   <?php
   ini_set('display_errors', 1);
   error_reporting(E_ALL);
   ?>
   ```

---

### Animation Doesn't Play

**Symptoms**: Logo appears but is static, no sliding/fading effects

**Diagnosis**:
1. Open browser DevTools (F12)
2. Go to **Network** tab
3. Reload page
4. Check if `logo-animated.css` loads (status 200)
5. Go to **Console** tab - look for CSS errors

**Solutions**:

1. **CSS not loading**:
   ```html
   <!-- Check <head> section has: -->
   <link rel="stylesheet" href="/css/logo-animated.css">
   ```

2. **CSS path incorrect**:
   ```html
   <!-- Wrong -->
   <link rel="stylesheet" href="css/logo-animated.css">
   
   <!-- Correct (absolute path) -->
   <link rel="stylesheet" href="/css/logo-animated.css">
   ```

3. **CSS cached by browser**:
   - Hard refresh: `Ctrl + Shift + R` (Windows) or `Cmd + Shift + R` (Mac)
   - Or add version parameter:
   ```html
   <link rel="stylesheet" href="/css/logo-animated.css?v=1.0.1">
   ```

4. **CSS animations disabled by browser**:
   ```css
   /* Add to CSS to test */
   @media (prefers-reduced-motion: reduce) {
       .logo-animated svg * {
           animation: none !important;
       }
   }
   ```
   User may have "reduce motion" enabled in OS settings.

---

### Logo Appears But Spacing Is Wrong

**Symptoms**: "CHOOSE" and "90" overlap, too far apart, or misaligned

**Solution**:

Edit BOTH PHP files (static and WordPress versions):

**File 1**: `src/php/logo-animated.php`
```html
<!-- Line 33 -->
<text class="logo-text" x="235" y="95" ...>90</text>
<!-- Adjust x="235" value -->
```

**File 2**: `src/php/header-logo.php`
```html
<!-- Line 33 -->
<text class="logo-text" x="235" y="95" ...>90</text>
<!-- Must match File 1 -->
```

**Quick reference**:
- `x="200"` - Very close spacing
- `x="220"` - Close spacing
- `x="235"` - Default (balanced)
- `x="250"` - Wide spacing
- `x="270"` - Very wide spacing

---

### WordPress Plugin Not Activating

**Symptoms**: Plugin shows error on activation, or doesn't appear in plugin list

**Diagnosis**:
1. Check WordPress Admin → Plugins
2. Look for "Choose90 Logo System"
3. Check for error messages

**Solutions**:

1. **PHP syntax error**:
   - Check server error log: `/home/username/logs/error_log`
   - Or enable WP_DEBUG:
   ```php
   // wp-config.php
   define('WP_DEBUG', true);
   define('WP_DEBUG_LOG', true);
   ```

2. **File permissions too restrictive**:
   ```bash
   chmod 644 /wp-content/plugins/choose90-logo-system.php
   ```

3. **Plugin header missing**:
   - File MUST start with:
   ```php
   <?php
   /**
    * Plugin Name: Choose90 Logo System
    * ...
    */
   ```

4. **Security plugin blocking**:
   - Check Wordfence, BPS, Sucuri scans
   - Whitelist `choose90-logo-system.php`

---

### Static HTML Pages Show PHP Code

**Symptoms**: Page displays `<?php include ... ?>` as text instead of executing

**Diagnosis**: Server not processing PHP in `.php` files

**Solutions**:

1. **Verify file extension**:
   - File MUST be `.php`, not `.html`
   - `index.html` → rename to → `index.php`

2. **Check Apache PHP handler**:
   ```apache
   # Add to .htaccess
   AddType application/x-httpd-php .php
   ```

3. **Check Nginx PHP-FPM**:
   ```nginx
   location ~ \.php$ {
       include fastcgi_params;
       fastcgi_pass unix:/var/run/php/php7.4-fpm.sock;
   }
   ```

4. **Verify PHP is installed**:
   ```bash
   php -v
   # Should show: PHP 7.4.x or higher
   ```

---

### Logo Breaks Mobile Layout

**Symptoms**: Logo too large on mobile, overlaps navigation, or causes horizontal scroll

**Solution**:

Edit `src/css/logo-animated.css` responsive breakpoints:

```css
/* Line 97-109: Adjust mobile sizes */

@media (max-width: 768px) {
    .logo-animated svg {
        width: 140px;  /* Reduce further if needed: 120px, 100px */
    }
}

@media (max-width: 480px) {
    .logo-animated svg {
        width: 100px;  /* Smaller for phones */
    }
}
```

**Test on multiple devices**:
- Chrome DevTools → Toggle device toolbar (Ctrl+Shift+M)
- Test: iPhone SE (375px), iPad (768px), Desktop (1920px)

---

### Colors Don't Match Brand

**Symptoms**: Logo colors don't match site's color scheme

**Solution**:

1. **Get your brand colors** (hex codes):
   - Use color picker tool: https://imagecolorpicker.com/
   - Or check your style guide

2. **Update CSS**:
   ```css
   /* src/css/logo-animated.css - Lines 28-30 */
   .logo-animated svg .figure-blue { fill: #YOUR_PRIMARY_COLOR; }
   .logo-animated svg .figure-yellow { fill: #YOUR_SECONDARY_COLOR; }
   .logo-animated svg .figure-gray { fill: #YOUR_ACCENT_COLOR; }
   ```

3. **Update SVG inline (optional)**:
   Edit `src/php/logo-animated.php` and `src/php/header-logo.php`:
   ```html
   <ellipse class="figure-blue" cx="30" cy="50" rx="15" ry="25" fill="#YOUR_COLOR"/>
   ```

---

## 📊 Performance

### Metrics

**File Sizes** (uncompressed):
- `logo-animated.css`: 2.0KB
- `logo-animated.php`: 1.8KB
- `header-logo.php`: 1.9KB
- `logo-animated.js`: 2.7KB (optional)
- **Total**: ~8.4KB for complete system

**File Sizes** (gzipped - what browsers actually download):
- `logo-animated.css`: ~0.6KB
- `logo-animated.php`: ~0.5KB
- **Total**: ~1.1KB over the wire

**Page Load Impact**:
- First load: +1.1KB (gzipped CSS + inline SVG)
- Subsequent loads: ~0KB (CSS cached by browser)
- Rendering time: <50ms (CSS animations are GPU accelerated)

### Optimization Tips

1. **Enable gzip compression** (Apache):
   ```apache
   <IfModule mod_deflate.c>
       AddOutputFilterByType DEFLATE text/css
       AddOutputFilterByType DEFLATE image/svg+xml
   </IfModule>
   ```

2. **Set cache headers** (Apache):
   ```apache
   <FilesMatch "\.(css|js)$">
       Header set Cache-Control "max-age=31536000, public"
   </FilesMatch>
   ```

3. **Use HTTP/2**:
   - Enables multiplexing (faster parallel downloads)
   - Most hosts support HTTP/2 by default

4. **Lazy load fonts** (optional):
   ```html
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@700&display=swap" rel="stylesheet">
   ```

### Browser Compatibility

| Browser | Version | Support | Notes |
|---------|---------|---------|-------|
| Chrome | 43+ | ✅ Full | All features work |
| Firefox | 16+ | ✅ Full | All features work |
| Safari | 9+ | ✅ Full | All features work |
| Edge | 12+ | ✅ Full | All features work |
| IE 11 | 11 | ⚠️ Partial | Animations work, some SVG features limited |
| Opera | 30+ | ✅ Full | All features work |
| Mobile Safari | iOS 9+ | ✅ Full | Tested on iPhone 6+ |
| Chrome Mobile | Android 5+ | ✅ Full | Tested on Android 10+ |

**Fallback for IE11**:
```css
/* Disable animations if needed */
@media all and (-ms-high-contrast: none), (-ms-high-contrast: active) {
    .logo-animated svg * {
        animation: none !important;
    }
}
```

---

## 🔒 Security

### Security Measures Implemented

1. **Direct Access Prevention**:
   ```php
   // All PHP files check for WordPress context
   if (!defined('ABSPATH')) {
       exit; // Prevent direct access
   }
   ```

2. **No External Dependencies**:
   - Zero third-party libraries
   - Only optional: Google Fonts (reputable CDN)
   - No npm packages, no composer dependencies

3. **No Database Operations**:
   - Plugin doesn't write to database
   - Only uses WordPress transients (temporary, auto-expires)
   - No user data collected

4. **No File Modifications**:
   - Plugin doesn't create/modify files
   - Only loads CSS/fonts (read-only operations)

5. **WordPress Security Best Practices**:
   - Uses `wp_enqueue_style()` (prevents injection)
   - Uses `esc_url()` for all URLs
   - Uses `bloginfo()` for dynamic content
   - Follows WordPress Coding Standards

6. **Content Security Policy (CSP) Compatible**:
   ```html
   <!-- Add to your site's CSP header -->
   Content-Security-Policy: 
     style-src 'self' https://fonts.googleapis.com;
     font-src 'self' https://fonts.gstatic.com;
   ```

### Security Audit Checklist

✅ No `eval()` or `exec()` calls  
✅ No system command execution  
✅ No file uploads  
✅ No SQL queries  
✅ No user input processing  
✅ No cookies set  
✅ No external API calls (except Google Fonts CDN)  
✅ No obfuscated code  
✅ All code is human-readable  
✅ Follows principle of least privilege  

### Whitelist Instructions for Security Plugins

#### BulletProof Security (BPS)
1. WordPress Admin → **BPS Security**
2. Go to **Security Log**
3. Find alert for `choose90-logo-system.php`
4. Add to **HPF Ignore** textarea:
   ```
   choose90-logo-system.php
   ```
5. Save settings

#### Wordfence
1. WordPress Admin → **Wordfence** → **Scan**
2. Find `choose90-logo-system.php` in results
3. Click **Mark as Fixed** or **Ignore**
4. Select **Ignore always**

#### Sucuri
1. WordPress Admin → **Sucuri Security**
2. Go to **Settings** → **Alerts**
3. Add to **Ignore Alerts** list:
   ```
   /wp-content/plugins/choose90-logo-system.php
   ```

---

## 📝 Changelog

### Version 1.0.0 (December 12, 2024)

**Initial Release**

**Features**:
- ✅ Animated SVG logo with slide-in, fade, and scale effects
- ✅ WordPress plugin integration
- ✅ Theme integration support (functions.php)
- ✅ Static HTML page support (PHP includes)
- ✅ JavaScript fallback (optional)
- ✅ Responsive design with mobile breakpoints
- ✅ Hover effects with smooth transitions
- ✅ Accessibility compliance (ARIA labels)
- ✅ SEO optimized (semantic HTML, proper titles)
- ✅ Performance optimized (<2KB CSS gzipped)
- ✅ Browser compatibility (Chrome, Firefox, Safari, Edge, IE11 partial)

**Documentation**:
- ✅ Comprehensive README with installation guides
- ✅ Customization guide with code examples
- ✅ Troubleshooting section with solutions
- ✅ Deployment scripts (cPanel, SSH, PowerShell)
- ✅ Example implementations

**Files Included**:
- `src/css/logo-animated.css` (2.0KB)
- `src/php/logo-animated.php` (1.8KB)
- `src/php/header-logo.php` (1.9KB)
- `src/js/logo-animated.js` (2.7KB)
- `src/wordpress-plugin/choose90-logo-system.php` (2.0KB)
- Complete documentation suite
- Deployment automation scripts

---

## 🤝 Contributing

We welcome contributions! Here's how you can help:

### Reporting Bugs

1. Check if the issue already exists in [GitHub Issues](https://github.com/jmasoner/animated-logo/issues)
2. If not, create a new issue with:
   - **Title**: Brief description of the bug
   - **Description**: Detailed explanation of the problem
   - **Steps to reproduce**: How to recreate the bug
   - **Expected behavior**: What should happen
   - **Actual behavior**: What actually happens
   - **Environment**: Browser, OS, WordPress version (if applicable)
   - **Screenshots**: If visual bug

### Suggesting Enhancements

1. Open a GitHub Issue with:
   - **Title**: `[Enhancement] Your feature idea`
   - **Use case**: Why this feature would be useful
   - **Proposed solution**: How you envision it working
   - **Alternatives**: Other ways to achieve the same goal

### Submitting Pull Requests

1. **Fork the repository**
2. **Create a feature branch**:
   ```bash
   git checkout -b feature/your-feature-name
   ```
3. **Make your changes**:
   - Follow existing code style
   - Add comments for complex logic
   - Update documentation if needed
4. **Test thoroughly**:
   - Test in multiple browsers
   - Test WordPress integration
   - Test static HTML integration
5. **Commit with clear messages**:
   ```bash
   git commit -m "Add: New animation easing option for logo hover"
   ```
6. **Push to your fork**:
   ```bash
   git push origin feature/your-feature-name
   ```
7. **Open a Pull Request** with:
   - Description of changes
   - Why this change is needed
   - Screenshots/videos if visual change
   - Link to related issue (if applicable)

### Code Style Guidelines

**PHP**:
- Follow [WordPress Coding Standards](https://developer.wordpress.org/coding-standards/wordpress-coding-standards/php/)
- Use descriptive variable names
- Add PHPDoc comments for functions

**CSS**:
- Use 4-space indentation
- Group related properties together
- Add comments for each major section

**JavaScript**:
- Use ES6+ features (const/let, arrow functions)
- Add JSDoc comments
- Use meaningful variable names

---

## 💬 Support

### Get Help

**Option 1: GitHub Issues**
- Best for: Bug reports, feature requests
- URL: https://github.com/jmasoner/animated-logo/issues

**Option 2: Email Support**
- Email: john@masoner.us
- Response time: 24-48 hours
- Best for: Implementation questions, customization help

**Option 3: Phone Support** (Emergency/Priority)
- Phone: 360-513-4238
- Availability: Monday-Friday, 9am-5pm PST
- Best for: Urgent deployment issues, critical bugs

### Before Requesting Support

Please provide:
1. **Issue description**: What's not working?
2. **Expected behavior**: What should happen?
3. **Actual behavior**: What actually happens?
4. **Steps to reproduce**: How to recreate the issue?
5. **Environment**:
   - WordPress version (if applicable)
   - PHP version
   - Web server (Apache/Nginx)
   - Browser and version
6. **Screenshots**: If visual issue
7. **Error messages**: From browser console or server logs

### Frequently Asked Questions

**Q: Does this work with Elementor/Divi/Beaver Builder?**  
A: Yes! Use the WordPress plugin method and add the logo to your page builder's header template.

**Q: Can I use this on multiple sites?**  
A: Yes, the MIT license allows commercial and personal use on unlimited sites.

**Q: Will this slow down my site?**  
A: No. The entire system is <2KB gzipped, and CSS animations are GPU-accelerated.

**Q: Do I need to keep both PHP files?**  
A: Only if you use both WordPress and static HTML pages. WordPress-only sites need just `header-logo.php`.

**Q: Can I change the animation completely?**  
A: Yes! Edit the `@keyframes` in `logo-animated.css`. See [Customization Guide](#customization-guide).

**Q: Does this work with WooCommerce?**  
A: Yes, WooCommerce pages will display the logo just like other WordPress pages.

**Q: Can I add a tagline below the logo?**  
A: Yes! Edit the SVG and add:
```html
<text x="50" y="110" font-size="12" fill="#666">Your tagline here</text>
```

---

## 📜 License

MIT License

Copyright (c) 2024 John Masoner

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

### What This Means

✅ **You can**:
- Use commercially (on client sites, for profit)
- Modify the code (customize for your needs)
- Distribute (share with others, include in themes)
- Use privately (personal projects)
- Sublicense (include in paid products)

❌ **You cannot**:
- Hold the author liable for damages
- Use the author's name for promotion without permission

✅ **You must**:
- Include the license and copyright notice
- Indicate if changes were made (optional but recommended)

---

## 👤 Author

**John Masoner**

- **Email**: john@masoner.us
- **Phone**: 360-513-4238
- **GitHub**: [@jmasoner](https://github.com/jmasoner)
- **Project**: [animated-logo](https://github.com/jmasoner/animated-logo)
- **Organization**: Choose90.org

### About Choose90

Choose90 is a movement encouraging people to "Be the Good" by choosing to focus on 90% positive thoughts, words, and actions. This animated logo system was developed to provide a consistent, engaging visual identity across the Choose90 digital ecosystem.

**Learn more**: https://choose90.org

---

## 🙏 Acknowledgments

- **Google Fonts** for the beautiful Outfit typeface
- **WordPress** community for best practices documentation
- **SVG Working Group** for SVG standards
- **CSS Animation** community for inspiration
- **GitHub** for hosting this project

---

## 🗺️ Roadmap

### Version 1.1 (Planned)

- [ ] Add dark mode support (auto-detects `prefers-color-scheme`)
- [ ] Include alternative color schemes (5 preset themes)
- [ ] Add "skip animation" option for accessibility
- [ ] Create Gutenberg block for WordPress
- [ ] Add animation preview tool (HTML page)

### Version 1.2 (Future)

- [ ] React component version
- [ ] Vue component version
- [ ] Web component (custom element)
- [ ] npm package for easy installation
- [ ] Sass variables for easier customization

### Version 2.0 (Future)

- [ ] Interactive logo configurator (web-based)
- [ ] Multiple animation styles (slide, bounce, fade, zoom)
- [ ] SVG sprite sheet for better performance
- [ ] Animation timeline editor

**Want to contribute to the roadmap?** [Open an issue](https://github.com/jmasoner/animated-logo/issues) with your ideas!

---

## 📚 Additional Resources

### Related Documentation
- [WordPress Plugin Handbook](https://developer.wordpress.org/plugins/)
- [MDN: CSS Animations](https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Animations)
- [MDN: SVG Tutorial](https://developer.mozilla.org/en-US/docs/Web/SVG/Tutorial)
- [PHP: Include Documentation](https://www.php.net/manual/en/function.include.php)

### Tools Used in Development
- Visual Studio Code (code editor)
- Chrome DevTools (debugging)
- SVGOMG (SVG optimization)
- cssnano (CSS minification)

### Community
- [WordPress StackExchange](https://wordpress.stackexchange.com/)
- [CSS-Tricks](https://css-tricks.com/)
- [Stack Overflow](https://stackoverflow.com/questions/tagged/svg+animation)

---

<div align="center">

**[⬆ Back to Top](#choose90-animated-logo-system)**

Made with ❤️ for Choose90.org

*Be the Good. Choose 90.*

</div>
