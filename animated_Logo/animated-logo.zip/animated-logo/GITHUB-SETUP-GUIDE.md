# GitHub Repository Setup Guide

## 📋 Complete Guide for Creating Your GitHub Repo

This guide will walk you through setting up the **animated-logo** repository on GitHub and syncing it with your local computer.

---

## 🎯 Repository Information

- **Repository Name**: `animated-logo`
- **Repository URL**: https://github.com/jmasoner/animated-logo
- **Your GitHub Username**: `jmasoner`
- **Your Email**: john@masoner.us
- **Your Phone**: 360-513-4238
- **Local Directory**: `C:\Users\john\OneDrive\MyProjects\animated-logo`

---

## ⚙️ Step 1: Create Repository on GitHub

### Via GitHub Web Interface (Easiest)

1. **Go to GitHub**: https://github.com
2. **Sign in** with your account (`jmasoner`)
3. **Click the "+" icon** in the top right → **"New repository"**
4. **Fill in repository details**:
   - **Repository name**: `animated-logo`
   - **Description**: `A modular, reusable animated logo system for WordPress and static HTML sites`
   - **Visibility**: 
     - ✅ **Public** (recommended - allows others to use and contribute)
     - ⬜ Private (if you prefer to keep it private initially)
   - **Initialize repository**: 
     - ⬜ **Do NOT** check "Add a README file" (we already have one)
     - ⬜ **Do NOT** check "Add .gitignore" (we already have one)
     - ⬜ **Do NOT** check "Choose a license" (we already have MIT license)
5. **Click "Create repository"**

### What GitHub Will Show You

After creating, GitHub will display setup instructions. **Ignore those** - we'll use our own instructions below that match your downloaded files.

---

## 💻 Step 2: Set Up on Your Local Computer

### Prerequisites

**Install Git for Windows** (if not already installed):
1. Download: https://git-scm.com/download/win
2. Run installer with default settings
3. Verify installation:
   ```powershell
   git --version
   # Should show: git version 2.x.x
   ```

### Extract the ZIP File

1. **Download** the `animated-logo.zip` file you received
2. **Extract** to: `C:\Users\john\OneDrive\MyProjects\`
3. **Result**: You should have `C:\Users\john\OneDrive\MyProjects\animated-logo\`

### Verify Directory Structure

Open PowerShell and check:
```powershell
cd C:\Users\john\OneDrive\MyProjects\animated-logo
dir

# You should see:
# - README.md
# - LICENSE
# - CHANGELOG.md
# - CONTRIBUTING.md
# - .gitignore
# - src/
# - docs/
# - examples/
# - tests/
# - deployment/
```

---

## 🔗 Step 3: Initialize Git and Push to GitHub

### Method 1: Using PowerShell (Recommended)

Open **PowerShell** and run these commands:

```powershell
# Navigate to your project directory
cd C:\Users\john\OneDrive\MyProjects\animated-logo

# Initialize Git repository
git init

# Configure Git with your details (one-time setup)
git config user.name "jmasoner"
git config user.email "john@masoner.us"

# Add all files to staging
git add .

# Create first commit
git commit -m "Initial commit: Choose90 Animated Logo System v1.0.0

- Added animated SVG logo with multiple animation effects
- WordPress plugin integration
- Theme integration support
- Static HTML page support via PHP includes
- Comprehensive documentation (README, CHANGELOG, CONTRIBUTING)
- Deployment scripts for cPanel, SSH, and PowerShell
- MIT License

Project repository for Choose90.org animated logo system."

# Add GitHub as remote origin
git remote add origin https://github.com/jmasoner/animated-logo.git

# Rename default branch to 'main' (GitHub standard)
git branch -M main

# Push to GitHub
git push -u origin main
```

**Authentication Prompt:**
- GitHub will prompt for credentials
- Use your GitHub **username** and **Personal Access Token** (not password)
- **Don't have a token?** See [Creating a Personal Access Token](#creating-a-personal-access-token) below

### Method 2: Using GitHub Desktop (Easier for Beginners)

1. **Download GitHub Desktop**: https://desktop.github.com/
2. **Install** and **sign in** with your GitHub account
3. **File** → **Add Local Repository**
4. **Choose**: `C:\Users\john\OneDrive\MyProjects\animated-logo`
5. **Publish Repository** button in top right
6. Confirm repository name: `animated-logo`
7. Choose **Public** or **Private**
8. Click **Publish Repository**

---

## 🔑 Creating a Personal Access Token (PAT)

GitHub requires a Personal Access Token for HTTPS authentication.

### Steps:

1. **Go to GitHub**: https://github.com/settings/tokens
2. **Click**: "Generate new token" → "Generate new token (classic)"
3. **Give it a name**: `Animated Logo Repo Access`
4. **Select scopes**:
   - ✅ `repo` (Full control of private repositories)
5. **Set expiration**: Choose "90 days" or "No expiration"
6. **Click**: "Generate token"
7. **IMPORTANT**: **Copy the token immediately** (you won't see it again!)
8. **Store securely**: Save in a password manager

### Using the Token

When Git asks for credentials:
- **Username**: `jmasoner`
- **Password**: Paste your Personal Access Token (not your GitHub password)

**Windows Credential Manager** will remember this, so you only need to enter it once.

---

## ✅ Step 4: Verify Setup

### Check on GitHub

1. Go to: https://github.com/jmasoner/animated-logo
2. You should see:
   - ✅ README.md displayed on the homepage
   - ✅ All source files in `src/` directory
   - ✅ LICENSE file
   - ✅ CHANGELOG.md
   - ✅ CONTRIBUTING.md

### Check Locally

```powershell
cd C:\Users\john\OneDrive\MyProjects\animated-logo

# Check Git status
git status
# Should show: "On branch main, nothing to commit, working tree clean"

# Check remote connection
git remote -v
# Should show:
# origin  https://github.com/jmasoner/animated-logo.git (fetch)
# origin  https://github.com/jmasoner/animated-logo.git (push)
```

---

## 📝 Step 5: Making Updates

### Workflow for Future Changes

When you make changes to the logo system:

```powershell
# Navigate to project
cd C:\Users\john\OneDrive\MyProjects\animated-logo

# Check what files changed
git status

# Add specific files
git add src/css/logo-animated.css
git add README.md

# Or add all changes
git add .

# Commit with descriptive message
git commit -m "Update: Increased logo spacing by 20px

- Modified x-coordinate from 235 to 255 in both PHP files
- Updated documentation with new spacing value
- Tested on mobile and desktop viewports

Fixes #12"

# Push to GitHub
git push
```

### Commit Message Best Practices

Follow this format:
```
Type: Brief summary (50 chars max)

Detailed explanation of what changed and why.
Can be multiple lines. Wrap at 72 characters.

- Bullet points for specific changes
- Another change here

Fixes #issue_number (if applicable)
```

**Types:**
- `Add:` New features
- `Fix:` Bug fixes
- `Update:` Changes to existing features
- `Remove:` Removing features
- `Docs:` Documentation changes
- `Style:` Formatting changes
- `Refactor:` Code improvements without functionality changes

---

## 🏷️ Step 6: Creating Releases

### When to Create a Release

Create a release when you:
- Complete a new version (1.0.1, 1.1.0, etc.)
- Fix critical bugs
- Add significant new features

### How to Create a Release

#### Via GitHub Web Interface:

1. Go to: https://github.com/jmasoner/animated-logo
2. Click **"Releases"** (right sidebar)
3. Click **"Create a new release"**
4. Fill in details:
   - **Tag version**: `v1.0.0` (follow semantic versioning)
   - **Release title**: `Version 1.0.0 - Initial Release`
   - **Description**: Copy from CHANGELOG.md
5. **Attach files** (optional):
   - Upload `animated-logo.zip` for easy download
6. Click **"Publish release"**

#### Via Git Command Line:

```powershell
# Create and push a tag
git tag -a v1.0.0 -m "Version 1.0.0 - Initial Release"
git push origin v1.0.0

# Then create release on GitHub web interface
```

---

## 🌿 Step 7: Branching Strategy (Optional)

### For Solo Development

If you're the only developer:
```powershell
# Work directly on main branch
git checkout main
# Make changes, commit, push
```

### For Team Development

If others will contribute:

1. **Main branch**: Production-ready code only
2. **Develop branch**: Active development
3. **Feature branches**: Individual features

**Create a develop branch:**
```powershell
git checkout -b develop
git push -u origin develop
```

**Create a feature branch:**
```powershell
git checkout -b feature/dark-mode-support
# Make changes
git add .
git commit -m "Add: Dark mode support"
git push -u origin feature/dark-mode-support
# Then create Pull Request on GitHub
```

---

## 📚 Step 8: Repository Settings

### Recommended Settings on GitHub

1. **Go to Settings**: https://github.com/jmasoner/animated-logo/settings

2. **General**:
   - ✅ **Issues**: Enable (for bug reports and feature requests)
   - ✅ **Projects**: Enable (optional, for task tracking)
   - ⬜ **Wiki**: Disable (README is sufficient for now)
   - ⬜ **Discussions**: Enable if you want community Q&A

3. **Branches** → **Branch protection rules** (recommended for main):
   - ⬜ Require pull request reviews (if working with others)
   - ⬜ Require status checks to pass (if you set up CI/CD)

4. **Pages** (optional - for documentation hosting):
   - **Source**: Deploy from branch
   - **Branch**: `main` / folder: `docs`
   - Your docs will be at: `https://jmasoner.github.io/animated-logo/`

---

## 🔔 Step 9: Notifications and Watching

### Subscribe to Your Repository

1. Click **"Watch"** at the top of your repo
2. Choose notification level:
   - **All Activity**: Get notified of everything
   - **Participating and @mentions**: Only when you're involved
   - **Ignoring**: No notifications

### Email Notifications

GitHub will email you about:
- Issues created
- Pull requests submitted
- Comments on your commits
- Security alerts

**Configure**: https://github.com/settings/notifications

---

## 🤝 Step 10: Inviting Collaborators (Optional)

If you want others to contribute directly:

1. **Settings** → **Collaborators**
2. **Add people** → Enter their GitHub username
3. They'll receive an invitation email
4. They can then:
   - Push directly to the repository
   - Create branches
   - Merge pull requests

---

## 📊 Step 11: Adding a README Badge (Optional)

Make your README look professional with badges!

Add to top of README.md:
```markdown
![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![WordPress](https://img.shields.io/badge/WordPress-5.0%2B-blue.svg)
![PHP](https://img.shields.io/badge/PHP-7.4%2B-purple.svg)
```

More badges at: https://shields.io/

---

## 🐛 Troubleshooting

### "Permission denied (publickey)" Error

**Solution**: Use HTTPS instead of SSH, or set up SSH keys:
```powershell
# Check current remote URL
git remote -v

# If it shows git@github.com, change to HTTPS:
git remote set-url origin https://github.com/jmasoner/animated-logo.git
```

### "Repository not found" Error

**Causes**:
- Repository name misspelled
- Repository doesn't exist yet
- Using wrong GitHub account

**Solution**:
```powershell
# Verify remote URL
git remote -v

# Update if needed
git remote set-url origin https://github.com/jmasoner/animated-logo.git
```

### "Authentication failed" Error

**Causes**:
- Using GitHub password instead of Personal Access Token
- Token expired or doesn't have correct permissions

**Solution**:
1. Create a new Personal Access Token (see above)
2. Clear Windows Credential Manager:
   - Start → "Credential Manager"
   - Windows Credentials → Find `git:https://github.com`
   - Remove it
3. Try push again - Git will ask for new credentials

### "Fatal: not a git repository"

**Solution**: You're not in the project directory
```powershell
cd C:\Users\john\OneDrive\MyProjects\animated-logo
git status  # Should work now
```

---

## 📞 Getting Help

**Stuck? Need assistance?**

- **Email**: john@masoner.us
- **Phone**: 360-513-4238
- **GitHub Docs**: https://docs.github.com/en

**Common Resources**:
- [GitHub Desktop Guide](https://docs.github.com/en/desktop)
- [Git Cheat Sheet](https://education.github.com/git-cheat-sheet-education.pdf)
- [Markdown Guide](https://www.markdownguide.org/basic-syntax/)

---

## ✅ Final Checklist

Before considering your setup complete:

- [ ] GitHub repository created at `https://github.com/jmasoner/animated-logo`
- [ ] Local directory exists at `C:\Users\john\OneDrive\MyProjects\animated-logo`
- [ ] Git initialized and connected to GitHub
- [ ] All files pushed to GitHub (verified on website)
- [ ] README.md displays correctly on GitHub homepage
- [ ] Personal Access Token created and stored securely
- [ ] Git configured with your name and email
- [ ] Tested making a commit and pushing changes
- [ ] Repository settings configured (Issues enabled, etc.)
- [ ] Optional: Branch protection rules added
- [ ] Optional: Collaborators invited

---

## 🎓 Next Steps

Now that your repository is set up:

1. **Share the repository URL** with others: `https://github.com/jmasoner/animated-logo`
2. **Accept contributions**: Others can fork, contribute via pull requests
3. **Track issues**: Use GitHub Issues for bug reports and feature requests
4. **Create releases**: Tag stable versions for easy downloading
5. **Promote**: Share on social media, WordPress forums, dev communities

---

## 📜 Repository Description for GitHub

When setting up your repository, use this description:

**Short Description** (160 chars max):
```
A modular, reusable animated logo system for WordPress and static HTML sites. Lightweight, DRY-compliant, fully documented.
```

**Topics** (GitHub keywords for discoverability):
```
wordpress
wordpress-plugin
animated-logo
svg-animation
css-animation
logo-system
choose90
modular-design
php
javascript
static-site
responsive-design
```

**Website**:
```
https://choose90.org
```

---

<div align="center">

**[⬆ Back to README](README.md)**

**Repository Ready to Go!** 🚀

Made with ❤️ for Choose90.org  
*Be the Good. Choose 90.*

</div>
