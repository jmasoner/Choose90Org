<?php
/**
 * Plugin Name: Choose90 Logo System
 * Description: Loads animated logo CSS and fonts for Choose90.org
 * Version: 1.0.0
 * Author: Choose90
 * 
 * Installation:
 * 1. Upload this file to /wp-content/plugins/
 * 2. Activate in WordPress Admin > Plugins
 * 
 * This is SAFER than editing core files or theme files
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Enqueue animated logo CSS
 */
function choose90_enqueue_logo_styles() {
    // Enqueue logo animation CSS
    wp_enqueue_style(
        'choose90-logo-animated',
        home_url('/css/logo-animated.css'),
        array(),
        '1.0.0',
        'all'
    );
}
add_action('wp_enqueue_scripts', 'choose90_enqueue_logo_styles');

/**
 * Enqueue Outfit font (if not already loaded by theme)
 */
function choose90_enqueue_fonts() {
    wp_enqueue_style(
        'choose90-outfit-font',
        'https://fonts.googleapis.com/css2?family=Outfit:wght@700&display=swap',
        array(),
        null
    );
}
add_action('wp_enqueue_scripts', 'choose90_enqueue_fonts');

/**
 * Optional: Add admin notice on activation
 */
function choose90_logo_activation_notice() {
    ?>
    <div class="notice notice-success is-dismissible">
        <p><strong>Choose90 Logo System activated!</strong> Make sure these files exist:</p>
        <ul style="list-style: disc; margin-left: 20px;">
            <li><code>/css/logo-animated.css</code></li>
            <li><code>/includes/logo-animated.php</code></li>
            <li><code>/wp-content/themes/YOUR-THEME/template-parts/header-logo.php</code></li>
        </ul>
    </div>
    <?php
}

// Show notice only once after activation
register_activation_hook(__FILE__, function() {
    set_transient('choose90_logo_activated', true, 30);
});

add_action('admin_notices', function() {
    if (get_transient('choose90_logo_activated')) {
        choose90_logo_activation_notice();
        delete_transient('choose90_logo_activated');
    }
});
