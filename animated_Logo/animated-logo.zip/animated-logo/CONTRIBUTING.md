# Contributing to Choose90 Animated Logo System

First off, thank you for considering contributing to the Choose90 Animated Logo System! It's people like you that make this project better for everyone.

## 📋 Table of Contents

- [Code of Conduct](#code-of-conduct)
- [How Can I Contribute?](#how-can-i-contribute)
  - [Reporting Bugs](#reporting-bugs)
  - [Suggesting Enhancements](#suggesting-enhancements)
  - [Your First Code Contribution](#your-first-code-contribution)
  - [Pull Requests](#pull-requests)
- [Style Guides](#style-guides)
  - [Git Commit Messages](#git-commit-messages)
  - [PHP Style Guide](#php-style-guide)
  - [CSS Style Guide](#css-style-guide)
  - [JavaScript Style Guide](#javascript-style-guide)
  - [Documentation Style Guide](#documentation-style-guide)
- [Additional Notes](#additional-notes)

---

## 🤝 Code of Conduct

This project and everyone participating in it is governed by our commitment to creating a welcoming and respectful environment. By participating, you are expected to uphold this standard.

### Our Standards

**Examples of behavior that contributes to a positive environment:**
- Using welcoming and inclusive language
- Being respectful of differing viewpoints and experiences
- Gracefully accepting constructive criticism
- Focusing on what is best for the community
- Showing empathy towards other community members

**Examples of unacceptable behavior:**
- The use of sexualized language or imagery
- Trolling, insulting/derogatory comments, and personal attacks
- Public or private harassment
- Publishing others' private information without permission
- Other conduct which could reasonably be considered inappropriate

---

## 🛠 How Can I Contribute?

### Reporting Bugs

This section guides you through submitting a bug report. Following these guidelines helps maintainers and the community understand your report, reproduce the behavior, and find related reports.

**Before Submitting A Bug Report:**
1. **Check the [troubleshooting guide](README.md#troubleshooting)** - your issue might already be documented
2. **Search [existing issues](https://github.com/jmasoner/animated-logo/issues)** - the bug might already be reported
3. **Update to the latest version** - the bug might be fixed

**How to Submit A Good Bug Report:**

Create an issue on GitHub and provide the following information:

```markdown
## Bug Description
A clear and concise description of what the bug is.

## Steps to Reproduce
1. Go to '...'
2. Click on '...'
3. Scroll down to '...'
4. See error

## Expected Behavior
What you expected to happen.

## Actual Behavior
What actually happened.

## Screenshots
If applicable, add screenshots to help explain your problem.

## Environment
- **WordPress Version**: (e.g., 6.4.2 or N/A)
- **PHP Version**: (e.g., 8.0)
- **Web Server**: (e.g., Apache 2.4, Nginx 1.20)
- **Browser**: (e.g., Chrome 120, Firefox 121)
- **Operating System**: (e.g., Windows 11, macOS 14, Ubuntu 22.04)
- **Logo System Version**: (e.g., 1.0.0)

## Additional Context
Add any other context about the problem here.

## Error Messages
```
Paste any error messages from:
- Browser console (F12 → Console)
- Server error log
- WordPress debug.log
```
```

### Suggesting Enhancements

This section guides you through submitting an enhancement suggestion, including completely new features and minor improvements to existing functionality.

**Before Submitting An Enhancement:**
1. **Check the [roadmap](README.md#roadmap)** - it might already be planned
2. **Search [existing issues](https://github.com/jmasoner/animated-logo/issues)** - it might already be suggested

**How to Submit A Good Enhancement Suggestion:**

Create an issue on GitHub using this template:

```markdown
## Enhancement Summary
A clear and concise description of the enhancement.

## Problem It Solves
Explain what problem this enhancement would solve or what need it would fulfill.

## Proposed Solution
Describe how you envision this enhancement working.

## Alternative Solutions
Describe any alternative solutions or features you've considered.

## Use Case
Provide a specific example of how this would be used.

## Priority
How important is this to you?
- [ ] Critical (blocks my work)
- [ ] High (important for my project)
- [ ] Medium (nice to have)
- [ ] Low (future consideration)

## Willingness to Contribute
- [ ] I am willing to work on this feature
- [ ] I can test this feature when developed
- [ ] I can only provide feedback

## Additional Context
Any other context, screenshots, or mockups about the feature.
```

---

### Your First Code Contribution

Unsure where to begin contributing? You can start by looking through these issue labels:

- **`good first issue`** - Issues that are good for newcomers
- **`help wanted`** - Issues that need assistance
- **`documentation`** - Documentation improvements
- **`bug`** - Confirmed bugs that need fixing
- **`enhancement`** - New features or improvements

#### Setting Up Your Development Environment

1. **Fork the repository** on GitHub

2. **Clone your fork** locally:
   ```bash
   git clone https://github.com/YOUR-USERNAME/animated-logo.git
   cd animated-logo
   ```

3. **Create a branch** for your changes:
   ```bash
   git checkout -b feature/your-feature-name
   # or
   git checkout -b fix/your-bug-fix-name
   ```

4. **Set up a test environment**:
   - For WordPress testing: Install WordPress locally (XAMPP, Local by Flywheel, etc.)
   - For static HTML testing: Use any local web server (Apache, Nginx, PHP built-in server)

5. **Make your changes** following the [style guides](#style-guides)

6. **Test thoroughly**:
   - Test in multiple browsers (Chrome, Firefox, Safari, Edge)
   - Test WordPress integration (if applicable)
   - Test static HTML integration
   - Test responsive design (mobile, tablet, desktop)
   - Check browser console for errors

---

### Pull Requests

The process described here has several goals:
- Maintain code quality
- Fix problems that are important to users
- Engage the community in working toward the best possible solution
- Enable a sustainable system for maintainers to review contributions

**Before Submitting a Pull Request:**
1. Follow the [style guides](#style-guides)
2. Test your changes thoroughly
3. Update documentation if needed
4. Add your changes to CHANGELOG.md

**Pull Request Template:**

```markdown
## Description
Brief description of what this PR does.

## Related Issue
Fixes #(issue number)

## Type of Change
- [ ] Bug fix (non-breaking change fixing an issue)
- [ ] New feature (non-breaking change adding functionality)
- [ ] Breaking change (fix or feature causing existing functionality to change)
- [ ] Documentation update

## Changes Made
- Detailed list of changes
- Another change
- And another

## Testing Done
- [ ] Tested in Chrome
- [ ] Tested in Firefox
- [ ] Tested in Safari (if available)
- [ ] Tested in Edge (if available)
- [ ] Tested on mobile devices
- [ ] Tested WordPress integration (if applicable)
- [ ] Tested static HTML integration (if applicable)

## Screenshots
If applicable, add screenshots showing the changes.

## Checklist
- [ ] My code follows the style guidelines of this project
- [ ] I have performed a self-review of my own code
- [ ] I have commented my code, particularly in hard-to-understand areas
- [ ] I have made corresponding changes to the documentation
- [ ] My changes generate no new warnings
- [ ] I have added tests that prove my fix is effective or that my feature works
- [ ] New and existing unit tests pass locally with my changes
- [ ] Any dependent changes have been merged and published

## Additional Notes
Any additional information for reviewers.
```

**After Submitting:**
- Respond to review feedback promptly
- Make requested changes if needed
- Be patient - maintainers will review when available

---

## 📝 Style Guides

### Git Commit Messages

Follow these guidelines for commit messages:

**Format:**
```
Type: Short summary (50 chars or less)

More detailed explanatory text, if necessary. Wrap it to about 72
characters. Separate paragraphs with blank lines.

- Bullet points are okay
- Typically a hyphen or asterisk is used

Fixes #123
```

**Types:**
- `Add:` New feature or functionality
- `Fix:` Bug fix
- `Update:` Changes to existing features
- `Remove:` Removal of features or code
- `Docs:` Documentation changes
- `Style:` Formatting, missing semicolons, etc. (no code change)
- `Refactor:` Code change that neither fixes a bug nor adds a feature
- `Test:` Adding or updating tests
- `Chore:` Maintenance tasks, dependency updates

**Examples:**
```
Add: Dark mode support with auto-detection

Implemented prefers-color-scheme media query to detect system theme.
Updated CSS with dark mode color variables. Added toggle switch for
manual override.

- Created dark-mode.css with color overrides
- Added JavaScript toggle functionality
- Updated documentation with usage examples

Fixes #42
```

```
Fix: Logo spacing issue on mobile devices

Logo text was overlapping on screens smaller than 480px due to
fixed positioning. Changed to relative positioning with responsive
spacing.

Fixes #56
```

---

### PHP Style Guide

Follow [WordPress Coding Standards for PHP](https://developer.wordpress.org/coding-standards/wordpress-coding-standards/php/).

**Key Points:**

1. **Indentation**: Use tabs, not spaces
2. **Braces**: Opening brace on same line
3. **Spacing**: Space after control structures, commas
4. **Naming Conventions**:
   - Functions: `lowercase_with_underscores()`
   - Variables: `$lowercase_with_underscores`
   - Constants: `UPPERCASE_WITH_UNDERSCORES`

**Example:**
```php
<?php
/**
 * Enqueue the animated logo styles.
 *
 * Loads the logo CSS file with proper versioning and dependencies.
 * Hooks into WordPress's enqueue system for optimal performance.
 *
 * @since 1.0.0
 * @return void
 */
function choose90_enqueue_logo_styles() {
    // Enqueue the main logo stylesheet
    wp_enqueue_style(
        'choose90-logo-animated',
        get_stylesheet_directory_uri() . '/css/logo-animated.css',
        array(),
        '1.0.0',
        'all'
    );
}
add_action( 'wp_enqueue_scripts', 'choose90_enqueue_logo_styles' );
```

**Documentation Standards:**
- All functions must have PHPDoc blocks
- Include `@since` version tag
- Document all parameters with `@param`
- Document return values with `@return`
- Add inline comments for complex logic

---

### CSS Style Guide

**Key Principles:**
1. **Indentation**: 4 spaces (no tabs)
2. **Selectors**: One per line for multiple selectors
3. **Properties**: One per line
4. **Spacing**: Space after colon, no space before
5. **Organization**: Group related properties

**Example:**
```css
/* ============================================
   Logo Animation Styles
   ============================================
   Handles all animation keyframes and timing
   for the animated SVG logo component.
   ============================================ */

/* Base logo container */
.logo-animated {
    display: inline-block;
    text-decoration: none;
    transition: transform 0.3s ease;
}

/* Hover effect - scales logo slightly */
.logo-animated:hover {
    transform: scale(1.05);
}

/* SVG sizing - responsive */
.logo-animated svg {
    width: 180px;
    height: auto;
    display: block;
}

/* Animation keyframes - slide in from left */
@keyframes slideInLeft {
    0% {
        transform: translateX(-150px);
        opacity: 0;
    }
    100% {
        transform: translateX(0);
        opacity: 1;
    }
}

/* Responsive breakpoint - tablet */
@media (max-width: 768px) {
    .logo-animated svg {
        width: 140px;
    }
}
```

**Organization:**
1. Base styles first
2. Layout properties
3. Typography
4. Visual effects (colors, borders)
5. Animations
6. Media queries last

---

### JavaScript Style Guide

**Key Principles:**
1. **Modern JS**: Use ES6+ features
2. **Indentation**: 4 spaces
3. **Semicolons**: Always use
4. **Quotes**: Single quotes for strings
5. **Variable Declaration**: Use `const` by default, `let` when needed, avoid `var`

**Example:**
```javascript
/**
 * Choose90 Animated Logo - JavaScript Component
 * 
 * Inserts the animated SVG logo into the DOM for environments
 * where PHP includes are not available.
 * 
 * @since 1.0.0
 */

(function() {
    'use strict';
    
    /**
     * Logo SVG markup
     * @type {string}
     */
    const logoSVG = `
        <a href="/" class="logo-animated" aria-label="Choose90 Home">
            <!-- SVG content -->
        </a>
    `;
    
    /**
     * Insert logo into container element
     * 
     * Finds the #animated-logo-container element and injects
     * the logo SVG markup. Logs warning if container not found.
     * 
     * @since 1.0.0
     * @return {void}
     */
    function insertLogo() {
        const container = document.getElementById('animated-logo-container');
        
        if (container) {
            container.innerHTML = logoSVG;
        } else {
            console.warn('Choose90 Logo: Container element #animated-logo-container not found');
        }
    }
    
    // Run on DOMContentLoaded or immediately if already loaded
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', insertLogo);
    } else {
        insertLogo();
    }
    
    // Export for manual initialization if needed
    window.Choose90Logo = {
        insert: insertLogo,
        svg: logoSVG
    };
})();
```

**JSDoc Standards:**
- Document all functions
- Use `@since` version tags
- Document parameters with `@param`
- Document return types with `@return`

---

### Documentation Style Guide

**Markdown Standards:**

1. **Headers**: Use ATX-style headers (`#`, `##`, `###`)
2. **Lists**: Use `-` for unordered, `1.` for ordered
3. **Code blocks**: Use fenced code blocks with language identifiers
4. **Links**: Use reference-style for repeated links
5. **Emphasis**: `**bold**` for UI elements, `*italic*` for emphasis

**Example:**
```markdown
## Installation Guide

### Prerequisites

Before installing, ensure you have:
- **WordPress**: Version 5.0 or higher
- **PHP**: Version 7.4 or higher
- **Web Server**: Apache or Nginx

### Step 1: Download Files

Download the latest release from [GitHub Releases](link).

### Step 2: Upload to Server

Upload files to these locations:

```bash
/css/logo-animated.css
/includes/logo-animated.php
```

### Step 3: Test Installation

Visit your site at `https://your-site.com/` to verify the logo appears.

**Troubleshooting**: If the logo doesn't appear, see the [troubleshooting guide](LINK).
```

**Documentation Checklist:**
- [ ] Clear and concise language
- [ ] Code examples with explanations
- [ ] Screenshots for visual steps (when applicable)
- [ ] Links to related documentation
- [ ] Troubleshooting tips
- [ ] Version compatibility notes

---

## 📞 Additional Notes

### Issue and Pull Request Labels

Labels help organize and prioritize work:

- **`bug`** - Something isn't working
- **`enhancement`** - New feature or request
- **`documentation`** - Improvements or additions to documentation
- **`good first issue`** - Good for newcomers
- **`help wanted`** - Extra attention is needed
- **`question`** - Further information is requested
- **`wontfix`** - This will not be worked on
- **`duplicate`** - This issue or pull request already exists
- **`invalid`** - This doesn't seem right
- **`priority:high`** - High priority
- **`priority:low`** - Low priority

### Getting Help

Stuck? Need help with your contribution?

- **GitHub Discussions**: Ask questions (when enabled)
- **Email**: john@masoner.us
- **Phone**: 360-513-4238 (for urgent matters)

### Recognition

Contributors will be acknowledged in:
- CHANGELOG.md for their specific contributions
- README.md contributors section
- GitHub contributors graph

---

## 📜 License

By contributing to this project, you agree that your contributions will be licensed under the same [MIT License](LICENSE) that covers the project.

---

<div align="center">

**Thank you for contributing!** 🎉

**[⬆ Back to README](README.md)**

Made with ❤️ for Choose90.org  
*Be the Good. Choose 90.*

</div>
