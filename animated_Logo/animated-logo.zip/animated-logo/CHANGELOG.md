# Changelog

All notable changes to the **Choose90 Animated Logo System** will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [Unreleased]

### Planned
- Dark mode support with `prefers-color-scheme` detection
- Alternative color scheme presets (5 themes)
- Accessibility "skip animation" option
- Gutenberg block for WordPress
- React and Vue component versions

---

## [1.0.0] - 2024-12-12

### Added
- Initial release of Choose90 Animated Logo System
- Animated SVG logo with multiple animation effects:
  - Slide-in from left (blue figure)
  - Slide-in from right (yellow figure)
  - Fade and scale (gray connecting figure)
  - Fade-in with vertical translation (text)
  - Smooth hover scale effect
- **WordPress Plugin** (`choose90-logo-system.php`)
  - Automatic CSS and font enqueueing
  - One-click activation in WordPress admin
  - Activation notice with setup checklist
  - Security hardened with ABSPATH check
- **Theme Integration** support via functions.php
  - Example code provided in documentation
  - Follows WordPress coding standards
- **Static HTML** integration via PHP includes
  - Reusable `logo-animated.php` component
  - Server-side rendering for better performance
- **JavaScript Fallback** (`logo-animated.js`)
  - Optional client-side insertion
  - For environments without PHP support
- **Responsive Design**
  - Mobile breakpoints: 768px (tablet) and 480px (phone)
  - Scales gracefully on all screen sizes
  - Touch-optimized for mobile devices
- **Performance Optimizations**
  - Lightweight CSS (~2KB uncompressed, 0.6KB gzipped)
  - Browser-cached styles for repeat visits
  - GPU-accelerated CSS animations
  - No external dependencies (except optional Google Fonts)
- **Accessibility Features**
  - ARIA labels for screen readers
  - Semantic HTML structure
  - Keyboard navigation support
  - Hover states for interactive elements
- **Documentation**
  - Comprehensive README with 38KB of documentation
  - Installation guides for 3 methods
  - Customization examples with code snippets
  - Troubleshooting section with solutions
  - Performance metrics and optimization tips
  - Security audit checklist
- **Example Files**
  - WordPress header.php example
  - Static HTML page example
  - Theme functions.php additions
- **Deployment Scripts**
  - cPanel deployment script (Bash)
  - SSH deployment script (Bash with rsync)
  - PowerShell deployment script (for Windows/WebDisk)
- **Testing**
  - Demo HTML page for standalone testing
  - Browser compatibility verified:
    - Chrome 43+
    - Firefox 16+
    - Safari 9+
    - Edge 12+
    - Opera 30+
    - Mobile Safari (iOS 9+)
    - Chrome Mobile (Android 5+)
    - IE11 (partial support, graceful degradation)

### Technical Details
- **Languages**: PHP 7.4+, CSS3, JavaScript ES6+
- **Frameworks**: WordPress 5.0+ compatible
- **Standards**: Follows WordPress Coding Standards
- **License**: MIT License
- **File Sizes**:
  - CSS: 2.0KB (uncompressed), 0.6KB (gzipped)
  - PHP components: 1.8KB each
  - JavaScript fallback: 2.7KB
  - WordPress plugin: 2.0KB
  - Total system: ~8.4KB uncompressed, ~1.1KB gzipped

### Security
- Direct access prevention in all PHP files
- No database operations or file modifications
- WordPress security best practices followed
- Content Security Policy (CSP) compatible
- No `eval()`, `exec()`, or system commands
- All code is human-readable (no obfuscation)
- Security plugin whitelist instructions provided

### Browser Support
- ✅ Full support: Chrome, Firefox, Safari, Edge, Opera
- ⚠️ Partial support: IE11 (animations work, some SVG limitations)
- ✅ Mobile: iOS 9+, Android 5+

### Known Issues
- None reported at release

### Breaking Changes
- None (initial release)

---

## Version Numbering Scheme

This project uses [Semantic Versioning](https://semver.org/):

**MAJOR.MINOR.PATCH**

- **MAJOR**: Incompatible API changes (e.g., file structure changes)
- **MINOR**: New features, backward-compatible
- **PATCH**: Bug fixes, backward-compatible

Examples:
- `1.0.0` → `1.0.1`: Bug fix (patch)
- `1.0.1` → `1.1.0`: New feature added (minor)
- `1.1.0` → `2.0.0`: Breaking change (major)

---

## Upgrade Notes

### From Previous Versions

**This is the initial release.** No previous versions exist.

### Future Upgrades

When upgrading between versions:

1. **Always backup** your current installation first
2. **Read the changelog** for breaking changes
3. **Test on staging** environment before production
4. **Clear browser caches** after updating CSS files
5. **Check customizations** if you've modified core files

---

## Reporting Issues

Found a bug or have a suggestion? Please report it:

- **GitHub Issues**: https://github.com/jmasoner/animated-logo/issues
- **Email**: john@masoner.us
- **Phone**: 360-513-4238 (for critical issues)

When reporting bugs, please include:
- Version number (check `README.md` or plugin header)
- WordPress version (if applicable)
- PHP version
- Browser and OS
- Steps to reproduce
- Expected vs. actual behavior
- Screenshots or error messages

---

## Credits

### Version 1.0.0 Contributors
- **John Masoner** - Initial development, documentation, testing
  - GitHub: [@jmasoner](https://github.com/jmasoner)
  - Email: john@masoner.us

### Acknowledgments
- Google Fonts for the Outfit typeface
- WordPress community for best practices
- SVG Working Group for standards
- CSS Animation community for inspiration
- Choose90.org for project sponsorship

---

## Links

- **Repository**: https://github.com/jmasoner/animated-logo
- **Issues**: https://github.com/jmasoner/animated-logo/issues
- **Pull Requests**: https://github.com/jmasoner/animated-logo/pulls
- **Releases**: https://github.com/jmasoner/animated-logo/releases
- **Choose90 Website**: https://choose90.org
- **License**: [MIT License](LICENSE)

---

<div align="center">

**[⬆ Back to README](README.md)**

Made with ❤️ for Choose90.org  
*Be the Good. Choose 90.*

</div>
